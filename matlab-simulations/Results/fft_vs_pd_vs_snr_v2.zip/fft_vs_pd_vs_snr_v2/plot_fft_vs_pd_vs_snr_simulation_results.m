clear all;clc

snr_vector = zeros(1,length(-30:1:30));
pd = zeros(1,length(-30:1:30));
counter = 0;
NFFTv = [512, 1024, 2048];

hold on
for i=1:1:3
    snr_vector = zeros(1,length(-30:0.1:30));
    pd = zeros(1,length(-30:0.1:30));
    counter = 0;
    fft = NFFTv(i);
    for snr=-30:0.1:30
        if(fft==2048)
            filename = sprintf('pd_vs_snr_%dv2.mat',snr);
        else
           filename = sprintf('fft_%d_pd_vs_snr_%dv2.mat',fft,snr); 
        end
        load(filename);
        
        counter = counter + 1;
        snr_vector(counter) = snr;
        pd(counter) = detection_rate;
    end
    if(fft==512)
        plot(snr_vector,pd,'r')
    elseif(fft==1024)
        plot(snr_vector,pd,'g')
    else
        plot(snr_vector,pd,'b')
    end
end
